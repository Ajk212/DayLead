import kivy
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from datetime import datetime, timedelta, time
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.graphics import Rectangle, Color
from kivy.uix.widget import Widget
from kivy.properties import ObjectProperty
from kivy.uix.screenmanager import ScreenManager, Screen, CardTransition, FadeTransition
from kivymd.app import MDApp
from kivymd.uix.pickers import MDTimePickerDialHorizontal, MDModalDatePicker
from kivy.uix.popup import Popup
from kivy.core.audio import SoundLoader

#Set window size Width x Height
Window.size = (1200, 800)

#Window Manager controls variables needing to be transfered between screens and alarm popup 
class WindowManager(ScreenManager):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.alarmSound = None
        Clock.schedule_interval(self.alarm_comp, 1)

    def alarm_comp(self, dt):
        homeScreen = self.get_screen('home')
        alarmScreen = self.get_screen('alarm')

        alarmPath = alarmScreen.alarmPath

        hr, min, sec = homeScreen.hr, homeScreen.min, homeScreen.sec
        Ahr, Amin, Asec = alarmScreen.Ahr, alarmScreen.Amin, alarmScreen.Asec

        alarmTime = f"{Ahr:02}:{Amin:02}:{Asec:02}"

        if hr == Ahr and min == Amin and sec == Asec:
            self.alarm_Popup(alarmTime, alarmPath)
            return

    def alarm_Popup(self, alarmTime, alarmPath):
        
        self.alarmSound = SoundLoader.load(alarmPath)
        self.alarmSound.loop = True
        self.alarmSound.play()

        widg = BoxLayout(
            orientation = 'vertical',
            spacing = 15,
            padding = 15
        )

        widg.add_widget(Label(
            text = "Wake Up!",
            font_size = 80,
            halign = 'center'
        ))

        widg.add_widget(Label(
            text = alarmTime,
            font_size = 80,
            halign = 'center'
        ))

        stopButton = (Button(
            text = "Stop",
            font_size = 40,
            halign = 'center'
        ))

        self.alarmPopup = Popup(
            title = "Alarm",
            content = widg,
            size_hint = (.75, .75)
        )

        stopButton.bind(on_release = self.closePopup)

        widg.add_widget(stopButton)

        self.alarmPopup.open()

    def closePopup(self, instance):
        self.alarmPopup.dismiss()
        self.alarmSound.stop()

#HomeScreen has navigation buttons, time/date set, NightMode,
#and contains labels for date, time, reminders and habits
class HomeScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.hr = 0
        self.min = 0
        self.sec = 0
        self.day = 0
        self.month = 0
        self.year = 0
        self.clock_start = False
        Clock.schedule_interval(self.timeUpdate, 1)
   

    def setTime(self):
        time_dialog = MDTimePickerDialHorizontal()
        time_dialog.bind(on_cancel=self.Ton_cancel, on_ok=self.Ton_ok, time=self.get_time)
        time_dialog.open()

    def get_time(self, instance, time):
        self.hr = time.hour
        self.min = time.minute
        self.sec = 0

    def Ton_ok(self, instance):
        self.clock_start = True
        instance.dismiss()
        self.setDate()

    def Ton_cancel(self, instance):
        instance.dismiss()

    def timeUpdate(self, dt):
        if self.clock_start:

            self.sec +=1

            if self.sec >= 60:
                self.min += 1
                self.sec = 0

            if self.min >= 60:
                self.hr +=1
                self.min = 0

            if self.hr >= 24:
                self.hr = 0
                self.day += 1
            
            months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"]
            wkDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

            wkDay = wkDays[(self.day-1)%7]
            mon = months[self.month-1]

            self.ids.time_label.text = f'{self.hr:02d}:{self.min:02d}:{self.sec:02d}'

            self.ids.day_label.text = wkDay
            self.ids.date_label.text = f'{mon} {self.day}'

            NightScreen = self.manager.get_screen('night')
            NightScreen.ids.time_label.text = f'{self.hr:02d}:{self.min:02d}:{self.sec:02d}'

    def setDate(self):
        date_dialog = MDModalDatePicker()
        date_dialog.bind(on_cancel=self.Don_cancel, on_ok=self.Don_ok, on_select_day=self.get_day, on_select_month=self.get_month, on_select_year=self.get_year)
        date_dialog.open()

    def get_day(self, instance, day):
        self.day = day

    def get_month(self, instance, mon):
        self.month = mon

    def get_year(self, instance, yr):
        self.year = yr

    def Don_ok(self, instance):
        instance.dismiss()

    def Don_cancel(self, instance):
        instance.dismiss()


#Only contains time and return button
class NightScreen(Screen): 
    pass

#Contains Alarm setting, stopwatch, and controls alarm type
class AlarmScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        #Values set to -1 to counteract alarm popup on start, since both clock values start at 0
        self.Ahr = -1
        self.Amin = -1
        self.Asec = -1
        self.Shr = 0
        self.Smin = 0
        self.Ssec = 0
        self.Sms = 0
        self.SW_start = False
        self.alarmPath = "Alarms/Alarm_Light.WAV"
        

    def setAlarm(self):
        time_dialog = MDTimePickerDialHorizontal()
        time_dialog.bind(on_cancel=self.on_cancel, on_ok=self.on_ok, time=self.get_time)
        time_dialog.open()

    def get_time(self, instance, time):
        self.Ahr = time.hour
        self.Amin = time.minute
        self.Asec = 0

    def on_ok(self, instance):
        self.ids.alarm_set.opacity = 1
        self.ids.alarm_time.opacity = 1
        self.ids.no_alarm.opacity = 0
        self.ids.alarm_time.text = f'{self.Ahr:02d}:{self.Amin:02d}:{self.Asec:02d}'
        instance.dismiss()
        
    def on_cancel(self, instance):
        instance.dismiss()

    def clearAlarm(self):
        self.ids.alarm_set.opacity = 0
        self.ids.alarm_time.opacity = 0
        self.ids.no_alarm.opacity = 1
        self.Ahr = -1
        self.Amin = -1
        self.Asec = -1

    def alarmType(self):
        
        if self.ids.volume_button.text == "Light Sleeper":
            self.ids.volume_button.text = "Heavy Sleeper"
            self.alarmPath = "Alarms/Alarm_Heavy.WAV"

        elif self.ids.volume_button.text == "Heavy Sleeper":
            self.ids.volume_button.text = "Light Sleeper"
            self.alarmPath = "Alarms/Alarm_Light.WAV"

    def start_stop(self):
        if self.ids.StartStop.text == "Start":
            self.ids.StartStop.text = "Stop"
            self.SW_start = True
            self.SWsched = Clock.schedule_interval(self.SWupdate, 0.01)

        elif self.ids.StartStop.text == "Stop":
            self.ids.StartStop.text = "Start"
            self.SW_start = False
            self.SWsched.cancel()


    def resetSW(self):
        self.Sms = 0
        self.Shr = 0
        self.Smin = 0
        self.Ssec = 0
        self.ids.StopTime.text = f'{self.Smin:02d}:{self.Ssec:02d}:{int(self.Sms):02d}'

    def SWupdate(self, dt):
        if self.SW_start:

            self.Sms += 1

            if self.Sms >= 100:
                self.Ssec += 1
                self.Sms = 0
                
            if self.Ssec >= 60:
                self.Smin += 1
                self.Ssec = 0

            self.ids.StopTime.text = f'{self.Smin:02d}:{self.Ssec:02d}:{int(self.Sms):02d}'

#unfinished section. Needs to dynamicly create month layout
class CalendarScreen(Screen):
    
    pass

#Allows user to add notes to a kanban table, where progress can be marked
class KanbanScreen(Screen):
    
    def addNote(self):
        newText = self.ids.newNote.text

        if newText.strip() == '':
            return

        backlog_row = [
            (self.ids.BL_lb_01, self.ids.BL_im_01),
            (self.ids.BL_lb_02, self.ids.BL_im_02),
            (self.ids.BL_lb_03, self.ids.BL_im_03), 
            (self.ids.BL_lb_04, self.ids.BL_im_04), 
            (self.ids.BL_lb_05, self.ids.BL_im_05),
        ]

        for label, image in backlog_row:
            
            if label.text == '':

                label.text = newText
                label.opacity = 1
                image.opacity = 1

                self.ids.newNote.text = ''

                return

    def BL_to_UW(self, label_id, image_id):
        BL_label = getattr(self.ids, label_id)
        label_text = str(BL_label.text)
        BL_image = getattr(self.ids, image_id)

        if label_text.strip() == '':
            return

        underway_row = [
            (self.ids.UW_lb_01, self.ids.UW_im_01),
            (self.ids.UW_lb_02, self.ids.UW_im_02),
            (self.ids.UW_lb_03, self.ids.UW_im_03), 
            (self.ids.UW_lb_04, self.ids.UW_im_04), 
            (self.ids.UW_lb_05, self.ids.UW_im_05),
        ]

        for UW_label, UW_image in underway_row:
            
            if UW_label.text == '':

                UW_label.text = BL_label.text
                UW_label.opacity = 1
                UW_image.opacity = 1

                BL_label.text = ''
                BL_image.opacity = 0

                return

    def UW_to_CP(self, label_id, image_id):
        UW_label = getattr(self.ids, label_id)
        label_text = str(UW_label.text)
        UW_image = getattr(self.ids, image_id)

        if label_text.strip() == '':
            return

        complete_row = [
            (self.ids.CP_lb_01, self.ids.CP_im_01),
            (self.ids.CP_lb_02, self.ids.CP_im_02),
            (self.ids.CP_lb_03, self.ids.CP_im_03), 
            (self.ids.CP_lb_04, self.ids.CP_im_04), 
            (self.ids.CP_lb_05, self.ids.CP_im_05),
        ]

        for CP_label, CP_image in complete_row:
            
            if CP_label.text == '':

                CP_label.text = UW_label.text
                CP_label.opacity = 1
                CP_image.opacity = 1

                UW_label.text = ''
                UW_image.opacity = 0

                return

    def CP_to_DEL(self, label_id, image_id):
        CP_label = getattr(self.ids, label_id)
        CP_text = str(CP_label.text)
        CP_image = getattr(self.ids, image_id)
        
        if CP_text.strip() == '':
            return
        
        CP_label.text = ''
        CP_image.opacity = 0     

    def ClearAll(self):

        all_rows = [
            (self.ids.BL_lb_01, self.ids.BL_im_01),
            (self.ids.BL_lb_02, self.ids.BL_im_02),
            (self.ids.BL_lb_03, self.ids.BL_im_03), 
            (self.ids.BL_lb_04, self.ids.BL_im_04), 
            (self.ids.BL_lb_05, self.ids.BL_im_05),
            (self.ids.UW_lb_01, self.ids.UW_im_01),
            (self.ids.UW_lb_02, self.ids.UW_im_02),
            (self.ids.UW_lb_03, self.ids.UW_im_03), 
            (self.ids.UW_lb_04, self.ids.UW_im_04), 
            (self.ids.UW_lb_05, self.ids.UW_im_05),
            (self.ids.CP_lb_01, self.ids.CP_im_01),
            (self.ids.CP_lb_02, self.ids.CP_im_02),
            (self.ids.CP_lb_03, self.ids.CP_im_03), 
            (self.ids.CP_lb_04, self.ids.CP_im_04), 
            (self.ids.CP_lb_05, self.ids.CP_im_05)
        ]

        for label, image in all_rows:    
                label.text = ''
                image.opacity = 0   

#contains daily habits. Allows user to add items and mark as completed or not. 
# After calendar integration, will keep a count of consecutive days of completion            
class HabitScreen(Screen):

    def clearAllHabits(self):
        rows = [
            (self.ids.hab01, self.ids.hab01_btn, self.ids.hab01_CP, self.ids.hab01_tog, self.ids.hab01_streak),
            (self.ids.hab02, self.ids.hab02_btn, self.ids.hab02_CP, self.ids.hab02_tog, self.ids.hab02_streak),
            (self.ids.hab03, self.ids.hab03_btn, self.ids.hab03_CP, self.ids.hab03_tog, self.ids.hab03_streak),
            (self.ids.hab04, self.ids.hab04_btn, self.ids.hab04_CP, self.ids.hab04_tog, self.ids.hab04_streak),
            (self.ids.hab05, self.ids.hab05_btn, self.ids.hab05_CP, self.ids.hab05_tog, self.ids.hab05_streak),
        ]

        for label, btn, comp, tog, strk in rows:    
                label.text = ''
                btn.opacity = 0   
                comp.opacity = 0
                tog.opacity = 0
                tog.disabled = True
                strk.text = '0'
                strk.opacity = 0

        HomeScreen = self.manager.get_screen('home')
        home_rows = [
            HomeScreen.ids.home_hab01,
            HomeScreen.ids.home_hab02,
            HomeScreen.ids.home_hab03,
            HomeScreen.ids.home_hab04,
            HomeScreen.ids.home_hab05,
        ]

        for label in home_rows:    
                label.text = ''

    def clearHabit(self, label_id, button_id, comp_id, tog_id, strk_id):
        Hab_label = getattr(self.ids, label_id)
        Hab_text = str(Hab_label.text)
        Hab_button = getattr(self.ids, button_id)
        Hab_comp = getattr(self.ids, comp_id)
        Hab_tog = getattr(self.ids, tog_id)
        Hab_strk = getattr(self.ids, strk_id)
        
        if Hab_text.strip() == '':
            return
        
        Hab_label.text = ''
        Hab_button.opacity = 0 
        Hab_comp.opacity = 0
        Hab_tog.disabled = True
        Hab_tog.opacity = 0
        Hab_strk.text = '0'  

        self.updateHabitList()


    def addToHabits(self, manual, label_text = '', tog_state = 'normal'):
        if manual == False:
            newHabit = self.ids.newHabit.text
        elif manual == True:
            newHabit = label_text

        if newHabit.strip() == '':
            return

        if tog_state == 'down':
            comp_text = 'Complete'
        else:
            comp_text = 'Incomplete'

        rows = [
            (self.ids.hab01, self.ids.hab01_btn, self.ids.hab01_CP, self.ids.hab01_tog, self.ids.hab01_streak),
            (self.ids.hab02, self.ids.hab02_btn, self.ids.hab02_CP, self.ids.hab02_tog, self.ids.hab02_streak),
            (self.ids.hab03, self.ids.hab03_btn, self.ids.hab03_CP, self.ids.hab03_tog, self.ids.hab03_streak),
            (self.ids.hab04, self.ids.hab04_btn, self.ids.hab04_CP, self.ids.hab04_tog, self.ids.hab04_streak),
            (self.ids.hab05, self.ids.hab05_btn, self.ids.hab05_CP, self.ids.hab05_tog, self.ids.hab05_streak),
        ]

        for label, btn, comp, tog, strk in rows:
            
            if label.text == '':

                label.text = newHabit
                label.opacity = 1
                btn.opacity = 1
                comp.opacity = 1
                comp.text = comp_text
                tog.disabled = False
                tog.state = tog_state
                tog.opacity = 1
                strk.opacity = 1

                self.ids.newHabit.text = ''

                break
        
        HomeScreen = self.manager.get_screen('home')
        home_rows = [
            HomeScreen.ids.home_hab01,
            HomeScreen.ids.home_hab02,
            HomeScreen.ids.home_hab03,
            HomeScreen.ids.home_hab04,
            HomeScreen.ids.home_hab05,

        ]

        for label in home_rows:    
            if label.text == '':
                label.text = newHabit
                return
        
    def updateHabitList(self):
 
        existing_habits = []
        rows = [
            (self.ids.hab01, self.ids.hab01_tog),
            (self.ids.hab02, self.ids.hab02_tog),
            (self.ids.hab03, self.ids.hab03_tog), 
            (self.ids.hab04, self.ids.hab04_tog), 
            (self.ids.hab05, self.ids.hab05_tog)
        ]

        for label, tog in rows:
            if label.text.strip() != '':
                existing_habits.append((label.text, tog.state))
        
        self.clearAllHabits()

        
        for label, tog in existing_habits:
            self.addToHabits(manual=True, label_text=label, tog_state=tog)

    def toggleComp(self, instance, comp_id):

        Hab_comp = getattr(self.ids, comp_id)

        if instance.state == 'down':
            Hab_comp.text = 'Complete'
        else:
            Hab_comp.text = 'Incomplete'

#Allows users to set reminders to be displayed on main screen
class ReminderScreen(Screen): 
    
    def clearAllReminder(self):
        all_rows = [
            (self.ids.rem01, self.ids.rem01_btn),
            (self.ids.rem02, self.ids.rem02_btn),
            (self.ids.rem03, self.ids.rem03_btn), 
            (self.ids.rem04, self.ids.rem04_btn), 
            (self.ids.rem05, self.ids.rem05_btn),
            (self.ids.rem06, self.ids.rem06_btn)
        ]

        for label, btn in all_rows:    
                label.text = ''
                btn.opacity = 0   

        HomeScreen = self.manager.get_screen('home')
        home_rows = [
            HomeScreen.ids.home_rem01,
            HomeScreen.ids.home_rem02,
            HomeScreen.ids.home_rem03,
            HomeScreen.ids.home_rem04,
            HomeScreen.ids.home_rem05,
            HomeScreen.ids.home_rem06
        ]

        for label in home_rows:    
                label.text = ''

    def clearReminder(self, label_id, button_id):
        rm_label = getattr(self.ids, label_id)
        rm_text = str(rm_label.text)
        rm_button = getattr(self.ids, button_id)
        
        if rm_text.strip() == '':
            return
        
        rm_label.text = ''
        rm_button.opacity = 0   

        self.updateList()

    #Manual checks if added through textbox, or reseting order
    def addToList(self, manual, label_text = ''): 
        if manual == False:
            newReminder = self.ids.newReminder.text
        elif manual == True:
            newReminder = label_text

        if newReminder.strip() == '':
            return

        rows = [
            (self.ids.rem01, self.ids.rem01_btn),
            (self.ids.rem02, self.ids.rem02_btn),
            (self.ids.rem03, self.ids.rem03_btn), 
            (self.ids.rem04, self.ids.rem04_btn), 
            (self.ids.rem05, self.ids.rem05_btn),
            (self.ids.rem06, self.ids.rem06_btn)
        ]

        for label, btn in rows:
            
            if label.text == '':

                label.text = newReminder
                btn.opacity = 1

                self.ids.newReminder.text = ''

                break

        HomeScreen = self.manager.get_screen('home')
        home_rows = [
            HomeScreen.ids.home_rem01,
            HomeScreen.ids.home_rem02,
            HomeScreen.ids.home_rem03,
            HomeScreen.ids.home_rem04,
            HomeScreen.ids.home_rem05,
            HomeScreen.ids.home_rem06
        ]

        for label in home_rows:    
            if label.text == '':
                label.text = newReminder
                return

    def updateList(self):
 
        existing_reminders = []
        rows = [
                self.ids.rem01,
                self.ids.rem02,
                self.ids.rem03,
                self.ids.rem04,
                self.ids.rem05,
                self.ids.rem06
        ]

        for label in rows:
            if label.text.strip() != '':
                existing_reminders.append(label.text)
        
        self.clearAllReminder()

        for label in existing_reminders:
            self.addToList(manual = True, label_text = label)


# Main app class
class MainApp(MDApp):
    def build(self):
        self.title = 'DayLead'
        return Builder.load_file('home_layout.kv')
  
#Opens window and runs app
if __name__ == '__main__':
    MainApp().run()
